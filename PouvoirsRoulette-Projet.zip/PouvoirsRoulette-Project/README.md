# PouvoirsRoulette

Plugin Minecraft **Java** pour serveurs **Paper 1.21.11** (API Paper), compilé avec Java 21.
Ce projet conserve la roulette, les pouvoirs, leurs noms, descriptions, raretés, effets et commandes déjà présents.

## Fonctionnalités présentes

- Roulette au premier passage du joueur (configurable).
- Animation de roulette avec ralentissement, sons, particules et annonce du résultat.
- Sauvegarde du pouvoir dans les données persistantes du joueur : il reste après déconnexion et redémarrage.
- Effets permanents et attributs réappliqués après reconnexion, mort/réapparition et consommation de lait.
- Pouvoirs spéciaux gérés par événements : vampire, double saut, faim, explosions, dégâts de feu, objet lâché, etc.
- Menus protégés contre le déplacement ou la récupération des objets.
- Commandes joueur et administration avec autocomplétion.

## Compatibilité

- **Minecraft Java Edition** uniquement.
- Serveur **Paper 1.21.11** recommandé.
- Java 21.
- Ce n'est pas un add-on Bedrock et il ne fonctionne pas directement sur un serveur Bedrock dédié.

## Compilation

À la racine du projet, avec Maven et Java 21 installés :

```bash
mvn -B clean package
```

Le plugin compilé sera créé dans `target/PouvoirsRoulette-1.0.0.jar`.

Le dépôt contient aussi un workflow GitHub Actions (`.github/workflows/build.yml`) qui compile le projet et publie le JAR comme artefact nommé `PouvoirsRoulette` à chaque push ou lancement manuel du workflow.

## Installation sur le serveur

1. Démarrer une fois le serveur Paper, puis l'arrêter.
2. Copier `PouvoirsRoulette-1.0.0.jar` dans le dossier `plugins/`.
3. Redémarrer le serveur.
4. Modifier `plugins/PouvoirsRoulette/config.yml` si nécessaire, puis redémarrer le serveur.

## Commandes

- `/pouvoir` : afficher son pouvoir ou ouvrir la roulette si le joueur doit encore tirer.
- `/pouvoir liste` : afficher les identifiants disponibles (permission admin).
- `/pouvoir reset <joueur>` : effacer le pouvoir et rendre la roulette disponible (permission admin).
- `/pouvoir set <joueur> <identifiant>` : attribuer un pouvoir précis (permission admin).

Permission d'administration : `pouvoirs.admin` (opérateur par défaut).

## Configuration

- `first-join-only: true` : seuls les nouveaux joueurs obtiennent la roulette automatiquement.
- `first-join-only: false` : tout joueur sans pouvoir obtient la roulette.
- `broadcast: true` : annonce le résultat à tout le serveur.
- `chance-cool: 0.6` : probabilité d'obtenir un pouvoir de rareté COOL. La valeur est limitée automatiquement entre 0 et 1.
