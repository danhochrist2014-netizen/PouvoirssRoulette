#!/usr/bin/env sh
set -eu
mvn -B clean package
printf '\nPlugin créé : target/PouvoirsRoulette-1.0.0.jar\n'
